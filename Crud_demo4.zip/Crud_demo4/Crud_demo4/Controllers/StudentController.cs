﻿using Crud_demo4.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;
using System.Net;

namespace Crud_demo4.Controllers
{
    public class StudentController : Controller
    {
        public readonly StudentDBcontext _dbcontext;
        public StudentController(StudentDBcontext Reg)
        {
            _dbcontext = Reg;
        }
        public IActionResult StudentList()
        {


            var std = (from a in _dbcontext.student_Reg
                       join b in _dbcontext.M_District on a.DistictId equals b.DistrictId into dis
                       from b in dis.DefaultIfEmpty()
                       select new Student
                       {
                           Id = a.Id,
                           FistName = a.FistName,
                           LastName = a.LastName,
                           address = a.address,
                           mobileno = (decimal)a.mobileno,
                           Gender = a.Gender,
                           DistictId = a.DistictId,
                           DistrictName = b == null ? "" : b.DistrictName,
                       });

            return View(std);
        }

      
        public IActionResult Create(Student obj)
        {
            List<District> cl = new List<District>();
            cl = (from c in _dbcontext.M_District select c).ToList();
            cl.Insert(0, new District { DistrictId = 0, DistrictName = "--Select Country Name--" });
            ViewBag.message = cl;

            return View(obj);
        }

        private void dropDistrict()
        {
            try
            {
                List<District> dis = new List<District>();
                dis = _dbcontext.M_District.ToList();

                ViewBag.Dis = dis;
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPost]
        public async Task<IActionResult> Add_stud(Student obj)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    if (obj.Id == 0)
                    {
                        _dbcontext.student_Reg.Add(obj);
                        await _dbcontext.SaveChangesAsync();
                    }
                    else { 
                       _dbcontext.Entry(obj).State = EntityState.Modified;
                        await _dbcontext.SaveChangesAsync();
                    }

                    return RedirectToAction("StudentList");
                }
                return View(obj);
            }
            catch (Exception ex)
            {
                return RedirectToAction("StudentList");
            }
        }

        public async Task<IActionResult> DeleteStud(int id)
        {
            try
            {
                if (id != 0)
                {
                    var del = _dbcontext.student_Reg.Find(id);

                    if (del != null)
                    { 
                       _dbcontext.Remove(del);
                        await _dbcontext.SaveChangesAsync();
                        
                        return RedirectToAction("StudentList");
                    }
                }

                return RedirectToAction("StudentList");
            }
            catch (Exception ex)
            {
                return RedirectToAction("StudentList");
            }
        }

    }
}
