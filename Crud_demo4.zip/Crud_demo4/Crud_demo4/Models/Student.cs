﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Crud_demo4.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; } 

        [Required(ErrorMessage ="required")]
        public string FistName { get; set; }
        
        [Required(ErrorMessage = "required")]
        public string LastName { get; set; }
        
        [Required(ErrorMessage = "required")]
        public string address { get; set; }
        
        [Required(ErrorMessage = "required")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Entered phone format is not valid.")]
        public decimal mobileno { get; set; }
        
        [Required(ErrorMessage = "required")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "required")]
        [Display(Name = "DistrictName")]
        public int DistictId { get; set; }
        
        [NotMapped]
        public string DistrictName { get; set; }

    }
}
