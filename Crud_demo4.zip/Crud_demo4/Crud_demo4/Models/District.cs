﻿namespace Crud_demo4.Models
{
    public class District
    {
        public int DistrictId { get; set; }

        public string DistrictName { get; set; }
    }
}
