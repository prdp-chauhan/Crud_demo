﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Crud_demo4.Models
{
    public class StudentDBcontext:DbContext
    {
        public StudentDBcontext(DbContextOptions<StudentDBcontext> options):base(options)
        {
                
        }

        public DbSet<Student> student_Reg { get; set; }

        public DbSet<District> M_District { get; set; }

    }
}
